package com.jsp.agro_springBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgroSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgroSpringBootApplication.class, args);
	}

}
